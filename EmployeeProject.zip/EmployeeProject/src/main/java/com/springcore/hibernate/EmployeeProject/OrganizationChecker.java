package com.springcore.hibernate.EmployeeProject;

import java.io.*;
import java.util.*;

public class OrganizationChecker {

    private static Map<String, Employee> employeeMap = new HashMap<>();
    private static Employee ceo;

    public static void main(String[] args) throws IOException {
        // This method will load the data from the csv file
        loadEmployeeData("C:\\Users\\chhot\\Downloads\\Documents\\Test\\EmployeeData.txt");

        // This method will analyze the salary structure for managers
        
        analyzeSalaryConditions();

        // This method will check for long reporting lines (more than 4 managers between employee and CEO)
        identifyLongReportingLines();
    }

    private static void loadEmployeeData(String filePath) throws IOException {
    	
    	
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;

        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            String id = data[0];
            String firstName = data[1];
            String lastName=data[2];
            int salary = Integer.parseInt(data[3]);
            String managerId = data[4];

            Employee employee = new Employee(id, firstName,lastName, salary, managerId);
            employeeMap.put(id, employee);

            // If this employee is the CEO, store it
            if (managerId.equals("NULL")) {
                ceo = employee;
            } else {
                // Add this employee to their manager's list of subordinates
                Employee manager = employeeMap.get(managerId);
                if (manager != null) {
                    manager.addSubordinate(employee);
                }
            }
        }

        reader.close();
    }

    private static void analyzeSalaryConditions() {
        // Iterate over each employee and check the salary conditions for managers
        for (Employee manager : employeeMap.values()) {
            if (manager.getManagerId() != null) {
                List<Employee> subordinates = manager.getSubordinates();
                if (!subordinates.isEmpty()) {
                    double totalSalary = 0;
                    for (Employee subordinate : subordinates) {
                        totalSalary += subordinate.getSalary();
                    }

                    double averageSalary = totalSalary / subordinates.size();

                    // Check if manager's salary is less than 20% of the average salary of its subordinates
                    
                    if(manager.getSalary() < averageSalary * 1.2)
                    {
                    	double diff= (int)averageSalary - manager.getSalary();
                    	System.out.println("The manager " + manager.firstName + " " + manager.lastName + " (ID: " + manager.id + ")" + " earns " + diff +"  less than 20% of the average salary of its subordinates");
                    }
                    
                    // Check if manager's salary is more than 50% of the average salary of its subordinates
                    else
                    {
                    	if(manager.getSalary() > averageSalary * 1.5)
                    	{
                    		double diff=  manager.getSalary() -(int)averageSalary ;
                    		System.out.println("The manager " + manager.firstName + " " + manager.lastName + " (ID: " + manager.id + ")" + " earns " + diff + " more than 50% of the average salary of its subordinates");
                    	}
                
                    }
                }
            }
        }
    }

    private static void identifyLongReportingLines() {
        // For each employee, calculate the reporting chain
        for (Employee employee : employeeMap.values()) {
            List<Employee> reportingChain = new ArrayList<>();
            Employee currentEmployee = employee;

            // Traverse the reporting chain upwards
            while (currentEmployee != null && currentEmployee.getManagerId() != null) {
                reportingChain.add(currentEmployee);
                currentEmployee = employeeMap.get(currentEmployee.getManagerId());
            }

            // If the reporting chain is longer than 4, print the employee's name
            if (reportingChain.size() > 4) {
                System.out.println("Employee " + employee.firstName + " "+ employee.lastName + " (ID: " + employee.id + ") has more than 4 managers between them and the CEO.");
            }
        }
    }
}
