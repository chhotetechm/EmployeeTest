package com.springcore.hibernate.EmployeeProject;

import java.util.ArrayList;
import java.util.List;

public class Employee {
    String id;
    String firstName;
    String lastName;
    int salary;
    String managerId; // The ID of the manager for this employee
    List<Employee> subordinates;

    // Constructor
    public Employee(String id, String firstName, String lastName,int salary, String managerId) {
        this.id = id;
        this.firstName = firstName;
        this.lastName=lastName;
        this.salary = salary;
        this.managerId = managerId;
        this.subordinates = new ArrayList<>();
    }

    public void addSubordinate(Employee subordinate) {
        subordinates.add(subordinate);
    }

    // Getter methods
    public String getId() {
        return id;
    }

    public String getManagerId() {
        return managerId;
    }

    public double getSalary() {
        return salary;
    }

    public List<Employee> getSubordinates() {
        return subordinates;
    }
}
